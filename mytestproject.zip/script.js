document.getElementById("loginForm").addEventListener("submit", function(event){
  event.preventDefault();
  // Add your login validation logic here
  // For example, check username and password
  let username = document.getElementById("username").value;
  let password = document.getElementById("password").value;
  // Dummy validation - replace with your actual validation logic
  if(username === "admin" && password === "admin123") {
    alert("Login successful!");
    // Redirect to dashboard or another page
  } else {
    alert("Invalid username or password. Please try again.");
  }
});
